clc
clear all
close all

load('Datos.mat'); %Cargo los datos

N=size(X,1); %Obtengo el n�mero de registros de la base de datos cargada

repeticiones=10; %Defino el n�mero de repeticiones o folds

% Se hace la partici�n de las muestras en subconjuntos de entrenamiento y prueba
rng('default');
particion=cvpartition(N,'Kfold',repeticiones);

ecm = 0;

for fold=1:repeticiones
    
        %%% Se hace la partici�n de las muestras %%%
        %%%      de entrenamiento y prueba       %%%
            
        indices=particion.training(fold);
        Xtrain=X(particion.training(fold),:);
        Xtest=X(particion.test(fold),:);
        Ytrain=Y(particion.training(fold),:);
        Ytest=Y(particion.test(fold),:);
        
        %Normalizo los datos
        [XtrainNormal,mu,sigma] = zscore(Xtrain);
        XtestNormal = (Xtest - repmat(mu,size(Xtest,1),1))./repmat(sigma,size(Xtest,1),1);
        
        %Creo la red neuronal
        net = feedforwardnet(5);
        
        % Se establece el maximo numero de epocas para el modelo
        net.trainParam.epochs = 1000;
        net.trainParam.goal = 0.01;
        %net.performParam.regularization = 0.01;
        %disp(net.trainParam.epochs);
        
        %Se entrena la red neuronal
        net = train(net, XtrainNormal', Ytrain');
        %view(net);
        
        %Se realiza la validacion
        Yest = sim(net, XtestNormal');
        
        ecm = ecm + mse(net, Ytrain', net(XtrainNormal'), 'regularization', 0.01);
        
end

%Muestro la gr�fica de la regresion
plotregression(Ytrain',net(XtrainNormal'),'Regression');

%obtengo el error atraves de la funcion mse que trae por defecto matlab
perf = ecm / 10;

disp(perf);
