  function Yesti = ventanaParzen(Xval,Xent,Yent,h,tipo)

          %%% La función debe retornar el valor de predicción Yesti para cada una de 
	  %%% las muestras en Xval. Por esa razón Yesti se inicializa como un vectores 
	  %%% de ceros, de dimensión M.
  
      M=size(Xval,1);
      N=size(Xent,1);
      
      Yesti=zeros(M,1);

      if strcmp(tipo,'regress')
      
	  for j=1:M
	    %%% Complete el codigo %%%

	    %%%%%%%%%%%%%%%%%%%%%%%%%%
	    
	  end
      
      elseif strcmp(tipo,'class')
	  
	  for j=1:M
	      %%% Complete el codigo %%%

	      %%%%%%%%%%%%%%%%%%%%%%%%%%
	      
	  end
	  
      end

  end
